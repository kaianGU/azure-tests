<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Selecionar Gerente_css-text-146c3p1 r-c_e60508</name>
   <tag></tag>
   <elementGuidId>72fa810a-1d56-45f6-9a6e-fe9a164a9c40</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Selecionar Gerente'])[1]/following::div[5]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.css-text-146c3p1.r-color-cqee49.r-fontSize-ubezar</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;1 - KaianGerente&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c7626d47-83f2-487c-b12a-4bdb6029cf37</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>dir</name>
      <type>Main</type>
      <value>auto</value>
      <webElementGuid>bb202c82-b1a3-450b-ade0-48a4728230f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>css-text-146c3p1 r-color-cqee49 r-fontSize-ubezar</value>
      <webElementGuid>9501d74f-88eb-45f3-8905-901d2a6e9254</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>1 - KaianGerente</value>
      <webElementGuid>b62f6270-0add-4407-933b-97dd67dcb3b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[4]/div[@class=&quot;r-bottom-1p0dtai r-left-1d2f490 r-position-1xcajam r-right-zchlnj r-top-ipm5af r-zIndex-sfbmgh r-animationDuration-1ielgck r-animationTimingFunction-1uypc71 r-animationKeyframes-1qulhi1 r-transform-ghxds0&quot;]/div[@class=&quot;css-view-g5y9jx&quot;]/div[@class=&quot;css-view-g5y9jx r-bottom-1p0dtai r-left-1d2f490 r-position-1xcajam r-right-zchlnj r-top-ipm5af r-backgroundColor-1niwhzg&quot;]/div[@class=&quot;css-view-g5y9jx r-flex-13awgt0 r-top-ipm5af&quot;]/div[@class=&quot;css-view-g5y9jx r-alignItems-1awozwy r-backgroundColor-tyl6gl r-flex-13awgt0 r-justifyContent-1777fci&quot;]/div[@class=&quot;css-view-g5y9jx r-backgroundColor-14lw9ot r-borderRadius-1ylenci r-maxHeight-f9v2oj r-padding-1pcd2l5 r-width-1akxima&quot;]/div[@class=&quot;css-view-g5y9jx r-WebkitOverflowScrolling-150rngu r-flexDirection-eqz5dr r-flexGrow-16y2uox r-flexShrink-1wbh5a2 r-overflowX-11yh6sk r-overflowY-1rnoaur r-transform-agouwx&quot;]/div[@class=&quot;css-view-g5y9jx&quot;]/div[@class=&quot;css-view-g5y9jx&quot;]/div[@class=&quot;css-view-g5y9jx r-transitionProperty-1i6wzkk r-userSelect-lrvibr r-cursor-1loqt21 r-touchAction-1otgn73 r-borderBottomColor-18wd4mo r-borderBottomWidth-qklmqi r-padding-xyw6el&quot;]/div[@class=&quot;css-text-146c3p1 r-color-cqee49 r-fontSize-ubezar&quot;]</value>
      <webElementGuid>013bcd23-0e5c-4fc8-8f46-11ad5fd2dd64</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Selecionar Gerente'])[1]/following::div[5]</value>
      <webElementGuid>af4921d9-17bb-4f29-8be7-e48e11e04015</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sair'])[1]/following::div[16]</value>
      <webElementGuid>3b7efecc-469c-4b92-bc4d-eeb943c6efa1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancelar'])[1]/preceding::div[25]</value>
      <webElementGuid>129b5c78-3b02-44db-8216-21bcc563f271</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div[2]/div/div/div/div</value>
      <webElementGuid>43493682-cd1c-491d-a3f7-7c8dc97973d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '1 - KaianGerente' or . = '1 - KaianGerente')]</value>
      <webElementGuid>a54e34b4-3a86-4d39-867d-862293800338</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
